export interface PawnType {
  id?:number;
  name?:string;
}
