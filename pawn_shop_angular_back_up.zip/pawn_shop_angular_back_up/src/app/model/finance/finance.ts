export interface Finance {
  id?:number;
  strongBoxMoney?:number;
  currentCapital?:number;
}
