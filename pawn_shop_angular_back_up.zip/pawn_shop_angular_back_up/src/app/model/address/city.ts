export interface City {
  id?:number;
  prefix?:string;
  name?:string;
}
