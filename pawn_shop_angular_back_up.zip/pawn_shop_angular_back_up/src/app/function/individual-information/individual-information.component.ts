import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-individual-information',
  templateUrl: './individual-information.component.html',
  styleUrls: ['./individual-information.component.css']
})
export class IndividualInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
