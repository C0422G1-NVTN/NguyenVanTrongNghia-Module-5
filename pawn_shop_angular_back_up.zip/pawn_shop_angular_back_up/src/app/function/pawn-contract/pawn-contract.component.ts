import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pawn-contract',
  templateUrl: './pawn-contract.component.html',
  styleUrls: ['./pawn-contract.component.css']
})
export class PawnContractComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
