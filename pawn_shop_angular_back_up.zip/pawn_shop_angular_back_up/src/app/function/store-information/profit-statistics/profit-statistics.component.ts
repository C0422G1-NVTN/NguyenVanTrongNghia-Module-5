import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profit-statistics',
  templateUrl: './profit-statistics.component.html',
  styleUrls: ['./profit-statistics.component.css']
})
export class ProfitStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
