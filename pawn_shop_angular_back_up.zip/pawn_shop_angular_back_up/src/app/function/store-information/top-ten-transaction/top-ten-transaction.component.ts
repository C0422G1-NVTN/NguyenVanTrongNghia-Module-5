import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-ten-transaction',
  templateUrl: './top-ten-transaction.component.html',
  styleUrls: ['./top-ten-transaction.component.css']
})
export class TopTenTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
