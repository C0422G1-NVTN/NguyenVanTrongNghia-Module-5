import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pawn-item-list',
  templateUrl: './pawn-item-list.component.html',
  styleUrls: ['./pawn-item-list.component.css']
})
export class PawnItemListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
