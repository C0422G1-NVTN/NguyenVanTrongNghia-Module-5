import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-information',
  templateUrl: './store-information.component.html',
  styleUrls: ['./store-information.component.css']
})
export class StoreInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
