import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-item',
  templateUrl: './return-item.component.html',
  styleUrls: ['./return-item.component.css']
})
export class ReturnItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
