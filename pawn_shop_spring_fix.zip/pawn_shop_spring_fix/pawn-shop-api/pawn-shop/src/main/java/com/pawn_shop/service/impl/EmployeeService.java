package com.pawn_shop.service.impl;

import com.pawn_shop.service.IEmployeeService;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService implements IEmployeeService {
}
