package com.pawn_shop.service;

import com.pawn_shop.model.pawn.PawnImg;

public interface IPawnImgService {
    void savePawnImg (PawnImg pawnImg);
}
