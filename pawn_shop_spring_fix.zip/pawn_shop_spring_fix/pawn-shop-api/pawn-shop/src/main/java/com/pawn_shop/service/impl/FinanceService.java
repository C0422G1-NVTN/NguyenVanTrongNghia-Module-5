package com.pawn_shop.service.impl;

import com.pawn_shop.service.IFinanceService;

public class FinanceService implements IFinanceService {
}
