package com.pawn_shop.model.login;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginRequest {

    String username;

    String password;

}
