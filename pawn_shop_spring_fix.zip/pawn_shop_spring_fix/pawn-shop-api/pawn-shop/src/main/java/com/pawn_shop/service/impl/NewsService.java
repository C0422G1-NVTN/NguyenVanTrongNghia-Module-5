package com.pawn_shop.service.impl;

import com.pawn_shop.service.INewsService;

public class NewsService implements INewsService {
}
