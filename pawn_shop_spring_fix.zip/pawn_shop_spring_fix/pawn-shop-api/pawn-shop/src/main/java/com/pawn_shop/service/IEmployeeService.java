package com.pawn_shop.service;

public interface IEmployeeService {
}
